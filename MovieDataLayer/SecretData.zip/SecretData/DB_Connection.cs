﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieDataLayer.SecretData
{
    internal static class DB_Connection
    {
        public static readonly string ConnectionString = "host=cit.ruc.dk; db=cit06; uid=cit06; pwd=6fkEI8NdedtI"; 
    }
}
